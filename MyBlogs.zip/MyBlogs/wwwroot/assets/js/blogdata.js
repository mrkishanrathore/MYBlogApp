export let BlogsToShow = [];
// let BlogsToShow = [];

export function setBlogsToShow(newBlogData){
    BlogsToShow = newBlogData;
}